//
//  Pizza.swift
//  Shah_Wajaat-PizzaPlace_Final_Project
//
//  Created by user195769 on 4/17/21.
//

import Foundation
import UIKit


class Pizza{
    var name:String = ""
    var size:String = ""
    var price:String = ""
    var img:String = ""
    init(){
        
    }
}
